RIĦA. BRAND KIT — Edition 01, November 2026
Luxury fragrances, made accessible. · rihaperfumes.com

01_Brand-Book
  Riha-Brand-Book.pdf ... 13 pages: logo, clear space, colour versions, monogram,
                          misuse, colours, type, voice, imagery, contacts.

02_Logos  (every logo comes as SVG + PNG)
  01_Primary-Logo ...... RIĦA. + RIHAPERFUMES.COM, transparent background
                         orange-white  → dark / charcoal backgrounds (main logo)
                         orange-charcoal → light backgrounds
                         white-charcoal → orange backgrounds
                         white / charcoal / black → one-colour use
  02_Wordmark .......... RIĦA. without the domain (for small sizes)
  03_Monogram .......... Ħ. symbol for profile pictures, seals, corners of Stories
  04_On-Background ..... ready-made 1080×1080 squares and 1920×1080 banners
  05_Social-and-Web .... profile pictures (1080×1080) and favicons (32/180/512 px)

  Which file?
    SVG → Figma, Canva (Pro), Illustrator, printers, website. Scales to any size.
    PNG → anywhere else. 1000px for posts, 2000px for print/flyers, 4000px for large print.

03_Fonts
  Poppins (free, OFL licence) + notes on ExtraBold download and Gilroy licence.

04_Colours
  Palette as PNG/SVG swatch, plain-text values (HEX / RGB / CMYK) and CSS variables.

Rules in one line: use the files, don't retype the logo; orange on charcoal,
white on orange, charcoal on light; always spell it Riħa.
