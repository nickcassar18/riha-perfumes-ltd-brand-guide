RIĦA. FONTS
===========

Headlines ........ Poppins ExtraBold (800)
Sub-heads/prices . Poppins Bold (700) / SemiBold (600)
Labels ........... Poppins Medium (500), ALL CAPS, letter-spacing +20%
Body ............. Poppins Regular (400)
Alternative body . Gilroy Regular

INCLUDED (Poppins folder)
  Light, Regular, Medium, Bold + their italics.
  Poppins is free under the SIL Open Font License (OFL.txt). You can install it,
  use it commercially and share it with designers.

TO DOWNLOAD (free)
  Poppins ExtraBold 800 and SemiBold 600 were not available to add here.
  Get the full family free from Google Fonts: fonts.google.com/specimen/Poppins
  Until then, Poppins Bold is the closest headline weight.

NOT INCLUDED (paid licence)
  Gilroy is a commercial font (Radomir Tinkov / Tinkov Fonts), so it can't be
  shared in this kit. Buy a licence if you want to use it; Poppins Regular works
  everywhere in its place.

MALTESE LETTERS
  Poppins has ċ ġ ż. Some older copies of Poppins (including the files here)
  do not include ħ / Ħ, and apps swap in another font for that letter. Check
  "Riħa" looks right before publishing. The logo itself is artwork (see
  02_Logos), so it is never affected.

Install: double-click each .ttf → Install (Windows) / Install Font (Mac).
